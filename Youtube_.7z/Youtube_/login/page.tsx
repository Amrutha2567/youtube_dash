// apps/web/app/login/page.tsx
"use client";

import { signIn, useSession } from "next-auth/react";
import { useEffect } from "react";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const { data: session, status } = useSession();
  const router = useRouter();

  useEffect(() => {
    if (status === "authenticated") {
      router.push("/");
    }
  }, [status, router]);

  if (status === "loading") {
    return (
      <div className="h-screen flex items-center justify-center">
        <p>Checking session...</p>
      </div>
    );
  }

  return (
    <div className="h-screen flex items-center justify-center bg-gray-50">
      <div className="w-full max-w-sm p-6 bg-white rounded shadow">
        <h1 className="text-2xl font-bold text-center mb-4">
          YouTube Companion Dashboard
        </h1>

        <button
          onClick={() => signIn("google", { callbackUrl: "/" })}
          className="w-full py-3 bg-red-600 text-white rounded font-medium hover:bg-red-700 transition"
        >
          Sign in with Google
        </button>

        <p className="text-xs text-gray-500 mt-4 text-center">
          We request YouTube permissions to manage your video, comments, and metadata.
        </p>
      </div>
    </div>
  );
}
