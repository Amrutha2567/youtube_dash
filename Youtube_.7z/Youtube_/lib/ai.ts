export async function generateTitleSuggestions(
  title: string,
  description: string
): Promise<string[]> {
  const prompt = `
Suggest 3 improved YouTube video titles optimized for engagement and clarity.

Title: "${title}"
Description: "${description}"
`;

  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${process.env.AI_API_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: "gpt-4o-mini",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.7
    })
  });

  if (!res.ok) {
    throw new Error("AI request failed");
  }

  const data = await res.json();

  return data.choices[0].message.content
    .split("\n")
    .filter((t: string) => t.trim().length > 0);
}
