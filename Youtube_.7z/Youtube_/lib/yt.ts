const BASE_URL = "https://www.googleapis.com/youtube/v3";

async function ytFetch(
  url: string,
  accessToken: string,
  options: RequestInit = {}
) {
  const res = await fetch(url, {
    ...options,
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
      ...(options.headers || {})
    }
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(err);
  }

  return res.json();
}

export function getVideoDetails(videoId: string, accessToken: string) {
  return ytFetch(
    `${BASE_URL}/videos?part=snippet,statistics&id=${videoId}`,
    accessToken
  );
}

export function addComment(
  videoId: string,
  text: string,
  accessToken: string
) {
  return ytFetch(
    `${BASE_URL}/commentThreads?part=snippet`,
    accessToken,
    {
      method: "POST",
      body: JSON.stringify({
        snippet: {
          videoId,
          topLevelComment: {
            snippet: { textOriginal: text }
          }
        }
      })
    }
  );
}

export function replyToComment(
  commentId: string,
  text: string,
  accessToken: string
) {
  return ytFetch(
    `${BASE_URL}/comments?part=snippet`,
    accessToken,
    {
      method: "POST",
      body: JSON.stringify({
        snippet: {
          parentId: commentId,
          textOriginal: text
        }
      })
    }
  );
}

export function deleteComment(commentId: string, accessToken: string) {
  return ytFetch(
    `${BASE_URL}/comments?id=${commentId}`,
    accessToken,
    { method: "DELETE" }
  );
}

export function updateVideo(
  videoId: string,
  title: string,
  description: string,
  accessToken: string
) {
  return ytFetch(
    `${BASE_URL}/videos?part=snippet`,
    accessToken,
    {
      method: "PUT",
      body: JSON.stringify({
        id: videoId,
        snippet: {
