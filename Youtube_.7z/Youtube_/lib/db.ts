import { PrismaClient } from "@prisma/client";

export const prisma = new PrismaClient();

export async function logEvent(
  eventType: string,
  metadata: Record<string, any>
) {
  return prisma.event_logs.create({
    data: {
      event_type: eventType,
      metadata
    }
  });
}

export async function createNote(
  videoId: string,
  content: string,
  tags: string[]
) {
  return prisma.notes.create({
    data: {
      video_id: videoId,
      content,
      tags
    }
  });
}

export async function getNotes(
  videoId: string,
  search?: string,
  tag?: string
) {
  return prisma.notes.findMany({
    where: {
      video_id: videoId,
      ...(search && {
        content: { contains: search, mode: "insensitive" }
      }),
      ...(tag && {
        tags: { has: tag }
      })
    },
    orderBy: { created_at: "desc" }
  });
}
