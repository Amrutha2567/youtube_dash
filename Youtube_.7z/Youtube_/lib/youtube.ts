export async function getVideoDetails(videoId, accessToken) {}
export async function addComment(videoId, text, accessToken) {}
export async function replyToComment(commentId, text, accessToken) {}
export async function deleteComment(commentId, accessToken) {}
export async function updateVideo(videoId, title, desc, accessToken) {}
