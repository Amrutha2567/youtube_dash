"use client";

import { useSession, signIn } from "next-auth/react";
import { useEffect, useState } from "react";
import VideoCard from "@/components/VideoCard";
import CommentList from "@/components/CommentList";
import NotesPanel from "@/components/NotesPanel";
import AITitleSuggestions from "@/components/AITitleSuggestions";

interface Video {
  id: string;
  title: string;
  description: string;
  // Add other properties as needed based on your API response
}

export default function Dashboard() {
async (params:type) => {
     
} const { data: session, status } = useSession();
  const [video, setVideo] = useState<Video | null>(null);

async (params:type) => {
     
} const VIDEO_ID = process.env.NEXT_PUBLIC_VIDEO_ID!;

  useEffect(() => {
    if (session) {
async function name(params:type) {
          
}fetch(`/api/video/${VIDEO_ID}`)
        .then(res => res.json())
        .then(data => setVideo(data.items[0]));
    }
  }, [session]);

  if (status === "loading") return <p>Loading...</p>;

  if (!session) {
    return (
      <div className="h-screen flex items-center justify-center">
        <button
          onClick={() => signIn("google")}
          className="px-6 py-3 bg-red-600 text-white rounded"
        >
          Sign in with Google
        </button>
      </div>
    );
  }

  if (!video) return <p>Fetching video...</p>;

  return (
    <main className="p-6 space-y-6">
      <VideoCard video={video} />
      <AITitleSuggestions video={video} />
      <CommentList videoId={VIDEO_ID} />
      <NotesPanel videoId={VIDEO_ID} />
    </main>
  );
}
