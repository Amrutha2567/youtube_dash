"use client";

import { useState } from "react";

export default function AITitleSuggestions({ video }: any) {
  const [titles, setTitles] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  const generate = async () => {
    setLoading(true);
    const res = await fetch("/api/ai/title-suggestions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title: video.snippet.title,
        description: video.snippet.description
      })
    });
    const data = await res.json();
    setTitles(data.suggestions);
    setLoading(false);
  };

  return (
    <div className="border rounded p-4">
      <h2 className="font-semibold">AI Title Suggestions</h2>

      <button
        onClick={generate}
        className="mt-2 px-4 py-2 bg-black text-white rounded"
      >
        {loading ? "Generating..." : "Generate"}
      </button>

      <ul className="mt-3 space-y-2">
        {titles.map((t, i) => (
          <li key={i} className="p-2 bg-gray-100 rounded">
            {t}
          </li>
        ))}
      </ul>
    </div>
  );
}
