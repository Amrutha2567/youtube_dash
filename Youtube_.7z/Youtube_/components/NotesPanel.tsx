"use client";

import { useEffect, useState } from "react";

export default function NotesPanel({ videoId }: { videoId: string }) {
  const [notes, setNotes] = useState<any[]>([]);
  const [content, setContent] = useState("");

  useEffect(() => {
    fetch(`/api/notes?videoId=${videoId}`)
      .then(res => res.json())
      .then(setNotes);
  }, []);

  const addNote = async () => {
    const res = await fetch("/api/notes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ videoId, content, tags: [] })
    });
    setNotes([...notes, await res.json()]);
    setContent("");
  };

  return (
    <div className="border rounded p-4">
      <h2 className="font-semibold">Notes</h2>

      <textarea
        value={content}
        onChange={e => setContent(e.target.value)}
        className="border w-full p-2 mt-2"
      />

      <button
        onClick={addNote}
        className="mt-2 px-4 py-2 bg-green-600 text-white rounded"
      >
        Add Note
      </button>

      <ul className="mt-3 space-y-2">
        {notes.map(n => (
          <li key={n.id} className="bg-gray-100 p-2 rounded">
            {n.content}
          </li>
        ))}
      </ul>
    </div>
  );
}
