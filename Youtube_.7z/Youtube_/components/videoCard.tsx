"use client";

export default function VideoCard({ video }: any) {
  const { snippet, statistics } = video;

  return (
    <div className="border rounded p-4">
      <img src={snippet.thumbnails.medium.url} />
      <h1 className="text-xl font-bold mt-2">{snippet.title}</h1>
      <p className="text-sm text-gray-600">{snippet.description}</p>

      <div className="flex gap-4 mt-2 text-sm">
        <span>Views: {statistics.viewCount}</span>
        <span>Likes: {statistics.likeCount}</span>
      </div>
    </div>
  );
}
