"use client";

import { useEffect, useState } from "react";

export default function CommentList({ videoId }: { videoId: string }) {
  const [comments, setComments] = useState<any[]>([]);
  const [text, setText] = useState("");

  useEffect(() => {
    fetch(`/api/comments?videoId=${videoId}`)
      .then(res => res.json())
      .then(setComments);
  }, []);

  const addComment = async () => {
    await fetch(`/api/video/${videoId}/comment`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text })
    });
    setText("");
  };

  return (
    <div className="border rounded p-4">
      <h2 className="font-semibold">Comments</h2>

      <input
        value={text}
        onChange={e => setText(e.target.value)}
        className="border w-full p-2 mt-2"
        placeholder="Add comment"
      />

      <button
        onClick={addComment}
        className="mt-2 px-4 py-2 bg-blue-600 text-white rounded"
      >
        Comment
      </button>

      <ul className="mt-4 space-y-2">
        {comments.map(c => (
          <li key={c.id} className="bg-gray-100 p-2 rounded">
            {c.snippet.topLevelComment.snippet.textDisplay}
          </li>
        ))}
      </ul>
    </div>
  );
}
