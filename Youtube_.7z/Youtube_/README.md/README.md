GET    /api/video/:id
PUT    /api/video/:id

POST   /api/video/:id/comment
POST   /api/comment/:id/reply
DELETE /api/comment/:id

POST   /api/notes
GET    /api/notes?search=&tag=
PUT    /api/notes/:id
DELETE /api/notes/:id

POST   /api/ai/title-suggestions
